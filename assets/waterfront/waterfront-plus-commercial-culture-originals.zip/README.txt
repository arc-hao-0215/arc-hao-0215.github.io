Waterfront+ ready-to-upload original boards

Upload the two JPG images inside assets/waterfront/ to the same folder path in GitHub repository arc-hao-0215/arc-hao-0215.github.io on branch main.

Site HTML already references these exact paths. Keep filenames unchanged. Both images are original, unmodified JPEG files; the ZIP stores them without recompression.

When uploaded, hard refresh https://arc-hao-0215.github.io/waterfront-plus.html
